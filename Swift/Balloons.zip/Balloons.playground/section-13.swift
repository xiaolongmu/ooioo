let leftBalloonCannon = scene.childNodeWithName("//left_cannon")!
let rightBalloonCannon = scene.childNodeWithName("//right_cannon")!
