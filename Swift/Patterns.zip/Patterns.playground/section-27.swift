trainDescription(maglev)
trainDescription(train)