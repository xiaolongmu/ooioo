let goodNews = Status.OnTime
let badNews = Status.Delayed(minutes: 90)