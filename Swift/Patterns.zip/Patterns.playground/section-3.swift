for i in 1...100 {
    println(fizzBuzz(i))
}