class Train {
    var status = Status.OnTime
}