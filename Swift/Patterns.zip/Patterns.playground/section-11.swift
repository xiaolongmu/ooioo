enum Status {
    case OnTime
    case Delayed(minutes: Int)
}