let trainOne = Train()
let trainTwo = Train()
let trainThree = Train()

trainTwo.status = .Delayed(minutes: 2)
trainThree.status = .Delayed(minutes: 8)